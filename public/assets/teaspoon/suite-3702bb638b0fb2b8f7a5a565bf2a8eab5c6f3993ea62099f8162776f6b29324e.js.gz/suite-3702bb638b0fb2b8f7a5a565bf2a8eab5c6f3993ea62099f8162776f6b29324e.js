(function() {
  Teaspoon.Suite = (function() {
    function Suite() {}

    Teaspoon.Utility.include(Suite, Teaspoon.Mixins.FilterUrl);

    return Suite;

  })();

}).call(this);
